HUGS!
===============
Haxe Unity Glue...Stuff!
-------------------------
This library includes Haxe externs for Unity and .NET frameworks, generated via the cslibgen utility. It also
includes the HUGSWrapper "using" class, which includes various things to work around Haxe/C# translation issues, as
well as make working with Unity easier.


Documentation forthcoming... 
------------------------

But in the mean time, you can check out our <a href="http://blog.proletariat.com/post/63641237563/free-hugs">blog</a> post on it.






Additional libraries
-------------------------
<a href="https://github.com/AxGord/Pony">Pony</a>

For FlashDevelop Users
-------------------------
<a href="https://github.com/AxGord/FlashDevelop-HaXe-Projects-Templates">Projects Templates</a>
